// from data.js
var tableData = data;

// YOUR CODE HERE!
var tbody=d3.select("tbody");
console.log(data)

data.forEach(function(ufo){
    console.log(ufo);
    var row=tbody.append("tr")
    Object.entries(ufo).forEach(function([key, value]){
        console.log(key,value);
        var cell =tbody.append("td");
        cell.html(value);
    });
});

//clear the table
function cleartbody(){
    d3.select("tbody")
    .selectAll("tr").remove()
    .selectAll("td").remove()
};
//Display of ufo sightings
console.log(tableData);
ufo(tableData);

//filter
var button=d3.select("#filter-btn");

button.on("click", function(event){
    d3.event.preventDefault();
    cleartbody();
    var di = d3.select("#datetime").property("value");

    if(di.trim()=== ""){
        var fdata= tableData;
    } else {
        var fdata=tableData.filter(ufo => 
            ufo.datetime === di.trim());
    };

  // display message if no records found
  if (fdata.length == 0) {
    d3.select("tbody")
      .append("tr")
      .append("td")
        .attr("colspan", 7)
        .html("<h4>No Records Found</h4>");
  };

  console.log(fdata);
  tableDisplay(fdata);
});







